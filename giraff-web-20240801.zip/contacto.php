<!DOCTYPE html>
<html lang="es">

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Giraff Contacto</title>
    <link rel="icon" href="imagenes/favicon.gif" type="image/x-icon">
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="contacto.css">
</head>

<body>
    <header>
        <div class="header-top">
            <div id="Isologo_cabecera"><img src="imagenes/logo.png" class="logo"
                    alt="Isologo que dice Giraff SRL marca registada"></div>
            <div id="Slogan_cabecera" class="header-slogan">Calzado con altura</div>
        </div>
        <nav id="menu_principal" class="menu_principal">
            <ul>
                <li><a href="index.html">Inicio</a></li>
                <li><a href="empresa.html">Empresa</a></li>
                <li><a href="catalogo_dama.html">L&iacutenea Dama</a></li>
                <li><a href="catalogo_caballero.html">L&iacutenea Caballero</a></li>
                <li><a href="contacto.html">Contacto</a></li>
            </ul>
        </nav>
    </header>
    <h1>Nuestras v&iacuteas de Contacto</h1>
    <main class="contacto">
        <div>
            <div id="datos_contacto">
                <h3>Telefono:</h3>
                <a href="tel:+541146879550" target="_blank">+5411-4687-9550</a><br>
                <span id="pie_whatsapp" ><img src="imagenes/wpp_n.png" alt=""> WhatsApp <a href="https://wa.me/5491137564294">54 911 3756-4294</a></span><br>
                <h3>Correo electr&oacutenico:</h3>
                <p><a href="mailto:info@giraff.com.ar">info@giraff.com.ar</a></p>
                <br>
            </div>
            <?php if (!$_POST){ ?>
            <form id="form_contacto" action="contacto.php" method=post>
                <h3>D&eacutejenos su consulta:</h3><br>
                <label for="nombre">Nombre: </label><br>
                <input name="nombre" id="nombre" type="text" required><br><br>
                <label for="correo">Correo electr&oacutenico: </label><br>
                <input type="email" id="correo" name="correo" required><br><br>
                <label for="tema">Asunto: </label><br>
                <select name="tema" id="tema" required>
                    <option value="Ventas">Consultar a un vendedor</option>
                    <option value="Compras">Consulta para el area de compras</option>
                    <option value="Otro">Otras consultas</option>
                </select><br><br>
                <label for="mensaje">Mensaje:</label><br>
                <textarea name="mensaje" id="mensaje" rows="10" required></textarea><br><br>
                <button type="submit">Enviar</button>
                <button type="reset">Borrar</button>
            </form>
            <?php }else{
                //Estoy recibiendo el formulario, compongo el cuerpo
                $cuerpo = "Formulario enviado desde la web\n";
                $cuerpo .= "Sobre: " . $_POST["tema"] . "\n";
                $cuerpo = "De:\n";
                $cuerpo .= "Nombre: " . $_POST["nombre"] . "\n";
                $cuerpo .= "Email: " . $_POST_["email"] . "\n";
                $cuerpo .= "Mensaje: " . $_POST_["mensaje"] . "\n";

                //mando el correo...
                mail("geovifran@gmail.com","Formulario recibido desde la web sobre ".$_POST["tema"],$cuerpo);

                //doy las gracias por el envío
                echo "Gracias por rellenar el formulario. Se ha enviado correctamente.";
            }
            ?>
        </div>
        <div id="mapa">
            <iframe
                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3281.8498961555288!2d-58.50098285932154!3d-34.658493560506564!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x95bcc90575eae633%3A0xc389bfa962bdabc!2sTandil%206047%2C%20C1440%20AVY%2C%20Cdad.%20Aut%C3%B3noma%20de%20Buenos%20Aires!5e0!3m2!1ses-419!2sar!4v1717025427225!5m2!1ses-419!2sar"
                width="100%" height="450" style="border:0;" allowfullscreen="" loading="lazy"
                referrerpolicy="no-referrer-when-downgrade"></iframe>
        </div>
    </main>
    <footer id="pie">
        <div id="Isologo_pie">
            <img id="logo-pie" src="imagenes/logo_white.png" class="logo"
                alt="Isologo que dice Giraff SRL marca registada">
            <div id="social_nav">
                <div id="insta_item"><img src="imagenes/icono_instagram.png" alt=""></div>
                <div id="face_item"><img src="imagenes/icono_facebook.png" alt=""></div>
                <div id="x_item"><img src="imagenes/icono_threads.png" alt=""></div>
            </div>
        </div>
        <div id="dire_pie">
            <h4><img src="imagenes/icono_mapa.png" alt="">DIRECCI&OacuteN</h4>
            <p><a href="https://maps.app.goo.gl/5cuY8rSAmrbCpiSS8" target="_blank">Tandil 6047/49 <br>
                    C1440AVY -<br>
                    Ciudad Aut&oacutenoma de Buenos Aires<br>
                    Argentina</a></p>
        </div>
        <div id="cont_pie">
            <h4><img src="imagenes/icono_contacto.png" alt="">CONTACTO</h4>
            <p>+5411-4687-9550<br>
            <span id="pie_whatsapp" ><img src="imagenes/wpp.png" alt=""> WhatsApp <a href="https://wa.me/5491137564294">54 911 3756-4294</a></span><br>
            <a href="mailto:info@giraff.com.ar">info@giraff.com.ar</a>
            </p>
        </div>
        <div id="mapa_pie">
            <h4>MAPA DEL SITIO</h4>
            <ul>
                <li><a href="index.html">Inicio</a></li>
                <li><a href="empresa.html">Nosotros</a></li>
                <li><a href="catalogo_dama.html">L&iacutenea Dama</a></li>
                <li><a href="catalogo_caballero.html">L&iacutenea Caballero</a></li>
                <li><a href="contacto.html">Contacto</a></li>
            </ul>
        </div>
    </footer>
</body>
<script>
    const nombreInput = document.querySelector('input[name="nombre"]');

    nombreInput.addEventListener('blur', () => {
        if (nombreInput.value.trim() === '') {
            alert('Por favor, completa el campo de nombre.');
            document.querySelector('input[name="nombre"]').ariaPlaceholder = "Por favor escriba su mombre"
        }
    });

    // Realizar otras validaciones para los demás campos...
</script>

</html>