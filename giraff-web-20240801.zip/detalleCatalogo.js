// ubicar el mouse
function movimientoMouse(){
    let mouseX = e.clientX - c.offsetLeft
}